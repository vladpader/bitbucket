using System;
using System.IO;
using System.Net.Http;
using System.Text.Json;
using System.Text.Json.Serialization;
using Xunit;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using Allure.Xunit.Attributes;
using Allure.Net.Commons;

namespace MyWebApiProject.Tests
{
    public class ChatTests : IDisposable
    {
        private readonly IWebDriver _driver;
        private readonly WebDriverWait _wait;

        public ChatTests()
        {
            var options = new ChromeOptions();
            options.AddArgument("--headless");
            _driver = new ChromeDriver(options);
            _wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(20));
        }

        [Fact]
        [AllureTag("Chat", "Selenium")]
        [AllureSeverity(SeverityLevel.normal)]
        [AllureFeature("Messaging")]
        [AllureStory("User sends a message")]
        public void TestUserCanSendMessage()
        {
            var senderUsername = $"sender_{Guid.NewGuid()}";
            var senderEmail = $"{senderUsername}@example.com";
            var senderPassword = "Password123!";
            var senderRole = "User";

            var recipientUsername = $"recipient_{Guid.NewGuid()}";
            var recipientEmail = $"{recipientUsername}@example.com";
            var recipientPassword = "Password123!";
            var recipientRole = "User";

            Console.WriteLine("📌 Регистрация отправителя...");
            var senderId = RegisterUser(senderUsername, senderEmail, senderPassword, senderRole);

            Console.WriteLine("📌 Регистрация получателя...");
            var recipientId = RegisterUser(recipientUsername, recipientEmail, recipientPassword, recipientRole);

            Console.WriteLine("📌 Вход отправителя...");
            LoginUser(senderUsername, senderPassword);

            Console.WriteLine("📌 Отправка сообщения...");
            SendMessage(recipientId, "Hello, this is a test message!");

            Console.WriteLine("✅ Проверка отправленного сообщения...");
            AssertMessageSent("Вы: Hello, this is a test message!");
            LogoutUser();

            Console.WriteLine("📌 Вход получателя...");
            LoginUser(recipientUsername, recipientPassword);

            Console.WriteLine("✅ Проверка полученного сообщения...");
            AssertMessageReceived("Hello, this is a test message!");
            LogoutUser();
        }

        private string RegisterUser(string username, string email, string password, string role)
        {
            Console.WriteLine("🔗 Переход на страницу регистрации...");
            _driver.Navigate().GoToUrl("http://localhost:5201/Auth/Register");

            Console.WriteLine("📝 Заполнение формы регистрации...");
            var usernameInput = _wait.Until(d => d.FindElement(By.Id("Username")));
            usernameInput.SendKeys(username);

            var emailInput = _driver.FindElement(By.Id("Email"));
            emailInput.SendKeys(email);

            var passwordInput = _driver.FindElement(By.Id("Password"));
            passwordInput.SendKeys(password);

            var confirmPasswordInput = _driver.FindElement(By.Id("ConfirmPassword"));
            confirmPasswordInput.SendKeys(password);

            var registerButton = _driver.FindElement(By.Id("RegisterButton"));
            registerButton.Click();

            Console.WriteLine("✅ Ожидание загрузки главной страницы...");
            _wait.Until(d => d.FindElement(By.TagName("h1")).Text.Contains("Добро пожаловать"));

            Console.WriteLine("🔐 Аутентификация для запроса к API...");
            var loginData = new StringContent(
                $"{{\"username\":\"{username}\",\"password\":\"{password}\"}}",
                System.Text.Encoding.UTF8,
                "application/json"
            );

            var httpClient = new HttpClient(new HttpClientHandler { UseCookies = true });
            var authResponse = httpClient.PostAsync("http://localhost:5201/api/Auth/Login", loginData).Result;

            if (!authResponse.IsSuccessStatusCode)
            {
                var authError = authResponse.Content.ReadAsStringAsync().Result;
                Console.WriteLine($"❌ Ошибка авторизации: {authResponse.StatusCode} - {authError}");
                throw new HttpRequestException($"Авторизация не удалась: {authResponse.StatusCode}");
            }

            Console.WriteLine("✅ Аутентификация успешна, выполняем запрос к API...");

            var response = httpClient.GetAsync($"http://localhost:5201/api/User/by-username/{username}").Result;

            if (!response.IsSuccessStatusCode)
            {
                var errorContent = response.Content.ReadAsStringAsync().Result;
                Console.WriteLine($"❌ Ошибка API: {response.StatusCode} - {errorContent}");
                throw new HttpRequestException($"API вернул ошибку: {response.StatusCode}");
            }

            var jsonResponse = response.Content.ReadAsStringAsync().Result;

            try
            {
                var user = System.Text.Json.JsonSerializer.Deserialize<UserResponse>(jsonResponse, new System.Text.Json.JsonSerializerOptions { PropertyNameCaseInsensitive = true });

                if (user == null || string.IsNullOrEmpty(user.Id))
                {
                    throw new InvalidOperationException("❌ Не удалось получить идентификатор пользователя из API.");
                }

                Console.WriteLine($"🆔 Идентификатор пользователя: {user.Id}");
                return user.Id;
            }
            catch (System.Text.Json.JsonException ex)
            {
                Console.WriteLine($"❌ Ошибка при десериализации JSON: {ex.Message}");
                Console.WriteLine($"Ответ API: {jsonResponse}");
                throw;
            }
        }

        private class UserResponse
        {
            public string Id { get; set; } = string.Empty;
        }

        private void LoginUser(string username, string password)
        {
            Console.WriteLine("🔗 Переход на страницу входа...");
            _driver.Navigate().GoToUrl("http://localhost:5201/Auth/Login");

            Console.WriteLine("📝 Заполнение формы входа...");
            var usernameInput = _wait.Until(d => d.FindElement(By.Name("Username")));
            usernameInput.SendKeys(username);

            var passwordInput = _driver.FindElement(By.Name("Password"));
            passwordInput.SendKeys(password);

            Console.WriteLine("✅ Нажатие кнопки входа...");
            var loginButton = _driver.FindElement(By.TagName("button"));
            loginButton.Click();

            Console.WriteLine("⏳ Ожидание перенаправления на главную страницу...");
            _wait.Until(d => d.Url.Contains("/Index") || d.Url == "http://localhost:5201/");

            Console.WriteLine("🔗 Переход на страницу чата...");
            _driver.Navigate().GoToUrl("http://localhost:5201/Messages/Chat");

            Console.WriteLine("✅ Проверка страницы чата...");
            _wait.Until(d => d.FindElement(By.Id("ChatPage")));
        }

        private void LogoutUser()
        {
            Console.WriteLine("🔑 Выход из аккаунта...");
            var logoutButton = _wait.Until(d => d.FindElement(By.Id("LogoutButton")));
            logoutButton.Click();

            Console.WriteLine("✅ Ожидание страницы входа...");
            _wait.Until(d => d.FindElement(By.Id("LoginButton")));
        }

        private void SendMessage(string toUserId, string messageText)
        {
            Console.WriteLine("📨 Ожидание загрузки страницы чата...");
            var chatWindow = _wait.Until(d => d.FindElement(By.Id("chatWindow")));

            Console.WriteLine("📝 Выбор получателя из выпадающего списка...");
            var toUserIdSelect = _wait.Until(d => d.FindElement(By.Id("toUserId")));
            var selectElement = new OpenQA.Selenium.Support.UI.SelectElement(toUserIdSelect);
            selectElement.SelectByValue(toUserId);

            Console.WriteLine("📝 Ввод текста сообщения...");
            var messageInput = _driver.FindElement(By.Id("messageInput"));
            messageInput.Clear();
            messageInput.SendKeys(messageText);

            Console.WriteLine("🚀 Отправка сообщения...");
            var sendButton = _driver.FindElement(By.Id("sendButton"));
            sendButton.Click();

            Console.WriteLine("✅ Ожидание подтверждения отправки сообщения...");
            _wait.Until(d =>
            {
                var messages = d.FindElements(By.CssSelector("#chatWindow div"));
                foreach (var msg in messages)
                {
                    if (msg.Text.Contains($"Вы: {messageText}"))
                    {
                        return true;
                    }
                }
                return false;
            });
        }

        private void TakeScreenshot(string filename)
        {
            try
            {
                var screenshot = ((ITakesScreenshot)_driver).GetScreenshot();
                var filePath = Path.Combine(Directory.GetCurrentDirectory(), $"{filename}.png");
                screenshot.SaveAsFile(filePath);
                Console.WriteLine($"📸 Скриншот сохранен: {filePath}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Ошибка при создании скриншота: {ex.Message}");
            }
        }

        private void AssertMessageSent(string expectedMessage)
        {
            Console.WriteLine("✅ Проверка отправленного сообщения...");
            Assert.True(_wait.Until(d =>
                d.FindElement(By.Id("chatWindow")).Text.Contains(expectedMessage)));
        }

        private void AssertMessageReceived(string expectedMessage)
        {
            Console.WriteLine("✅ Проверка полученного сообщения...");

            Assert.True(_wait.Until(d =>
            {
                var messages = d.FindElements(By.CssSelector("#chatWindow div"));
                foreach (var msg in messages)
                {
                    if (msg.Text.Contains(expectedMessage))
                    {
                        return true;
                    }
                }
                return false;
            }), $"❌ Сообщение '{expectedMessage}' не найдено в чате.");
        }

        public void Dispose()
        {
            Console.WriteLine("🛑 Завершение работы WebDriver...");
            TakeScreenshot($"Dispose_{DateTime.Now:yyyyMMdd_HHmmss}");
            _driver.Quit();
        }
    }
}
