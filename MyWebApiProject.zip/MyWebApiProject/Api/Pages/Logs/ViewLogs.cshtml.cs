using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using MyWebApiProject.Models;
using MyWebApiProject.Services;

namespace MyWebApiProject.Pages.Logs
{
    [Authorize(Roles = "Admin")]
    public class ViewLogsModel : PageModel
    {
        private readonly AppDbContext _context;

        public List<LogEntry> Logs { get; set; } = new();

        public ViewLogsModel(AppDbContext context)
        {
            _context = context;
        }

        public async Task OnGetAsync()
        {
            Logs = await _context.LogEntries
                .OrderByDescending(log => log.Timestamp)
                .Take(100)
                .ToListAsync();
        }
    }
}
