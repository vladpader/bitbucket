using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Authorization;
using MyWebApiProject.Models;
using MyWebApiProject.Services;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;

namespace MyWebApiProject.Pages.Messages
{
    [Authorize]
    public class ChatModel : PageModel
    {
        private readonly AppDbContext _context;
        private readonly UserManager<AppUser> _userManager;

        public List<Message> Messages { get; set; } = new();
        public List<AppUser> Users { get; set; } = new();
        public string CurrentUserId { get; set; } = string.Empty;

        public ChatModel(AppDbContext context, UserManager<AppUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        public async Task OnGetAsync()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user != null)
            {
                CurrentUserId = user.Id;

                Messages = await _context.Messages
                    .Where(m => m.ToUserId == CurrentUserId || m.FromUserId == CurrentUserId)
                    .OrderBy(m => m.CreatedAt)
                    .ToListAsync();

                Users = await _context.Users
                    .Where(u => u.Id != CurrentUserId)
                    .Select(u => new AppUser { Id = u.Id, Email = u.Email })
                    .ToListAsync();
            }
        }
    }
}
