using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MyWebApiProject.Pages
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
           // noop
        }
    }
}
