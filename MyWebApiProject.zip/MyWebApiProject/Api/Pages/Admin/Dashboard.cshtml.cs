using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MyWebApiProject.Models;

namespace MyWebApiProject.Pages.Admin
{
    [Authorize(Roles = "Admin")]
    public class DashboardModel : PageModel
    {
        private readonly UserManager<AppUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;

        public List<UserViewModel> Users { get; set; } = new();

        [BindProperty]
        public string NewUserName { get; set; } = string.Empty;

        [BindProperty]
        public string NewUserEmail { get; set; } = string.Empty;

        [BindProperty]
        public string NewUserPassword { get; set; } = string.Empty;

        public string Message { get; set; } = string.Empty;

        public DashboardModel(UserManager<AppUser> userManager, RoleManager<IdentityRole> roleManager)
        {
            _userManager = userManager;
            _roleManager = roleManager;
        }

        public async Task OnGetAsync()
        {
            var users = _userManager.Users.ToList();

            foreach (var user in users)
            {
                var roles = await _userManager.GetRolesAsync(user);
                Users.Add(new UserViewModel
                {
                    Id = user.Id,
                    UserName = user.UserName!,
                    Email = user.Email!,
                    Role = roles.FirstOrDefault()
                });
            }
        }

        public async Task<IActionResult> OnPostAddUserAsync()
        {
            if (!ModelState.IsValid)
            {
                Message = "Ошибка валидации данных.";
                return Page();
            }

            var user = new AppUser
            {
                UserName = NewUserName,
                Email = NewUserEmail,
                EmailConfirmed = true
            };

            var result = await _userManager.CreateAsync(user, NewUserPassword);
            if (result.Succeeded)
            {
                await _userManager.AddToRoleAsync(user, "User");
                Message = "Пользователь успешно добавлен.";
            }
            else
            {
                Message = "Ошибка при добавлении пользователя: " + string.Join(", ", result.Errors.Select(e => e.Description));
            }

            return RedirectToPage();
        }

        public async Task<IActionResult> OnPostDeleteUserAsync(string id)
        {
            var user = await _userManager.FindByIdAsync(id);
            if (user != null)
            {
                await _userManager.DeleteAsync(user);
                Message = "Пользователь удалён.";
            }
            else
            {
                Message = "Пользователь не найден.";
            }

            return RedirectToPage();
        }

        public class UserViewModel
        {
            public string Id { get; set; } = string.Empty;
            public string UserName { get; set; } = string.Empty;
            public string Email { get; set; } = string.Empty;
            public string? Role { get; set; }
        }
    }
}
