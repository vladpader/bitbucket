#!/bin/sh

echo "✅ Обновление пакетов и установка необходимых утилит..."
apk update && apk add curl busybox-suid

echo "📝 Добавление cron-задания..."
echo "* * * * * /usr/bin/curl -X POST http://app/api/logs/parser/parse >> /var/log/cron.log 2>&1" > /etc/crontabs/root

echo "🔍 Содержимое crontab:"
cat /etc/crontabs/root

echo "🚀 Запуск cron..."
crond -f -L /var/log/cron.log

echo "❗ Cron завершил работу (это не должно происходить)."
