using System.ComponentModel.DataAnnotations.Schema;

namespace MyWebApiProject.Models
{
    public class Message
    {
        public int Id { get; set; }

        public string FromUserId { get; set; } = default!;
        [ForeignKey("FromUserId")]
        public AppUser FromUser { get; set; } = default!;

        public string ToUserId { get; set; } = default!;
        [ForeignKey("ToUserId")]
        public AppUser ToUser { get; set; } = default!;

        public string MessageText { get; set; } = default!;

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}
