using Microsoft.AspNetCore.Identity;

namespace MyWebApiProject.Models
{
    public class AppUser : IdentityUser
    {
        public DateTime RegistrationDate { get; set; } = DateTime.UtcNow;
    }
}
