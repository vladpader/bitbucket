using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MyWebApiProject.Models
{
    public class LogEntry
    {
        [Key]
        public int Id { get; set; }

        public string IPAddress { get; set; } = string.Empty;

        public string User { get; set; } = string.Empty;

        [Required]
        [Column(TypeName = "timestamp with time zone")]
        public DateTime Timestamp { get; set; }

        public string Request { get; set; } = string.Empty;

        public int StatusCode { get; set; }

        public int ResponseSize { get; set; }
    }
}
