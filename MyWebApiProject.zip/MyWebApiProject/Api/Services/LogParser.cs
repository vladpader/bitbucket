using System.Text.RegularExpressions;
using MyWebApiProject.Models;

namespace MyWebApiProject.Services
{
    public class LogParser
    {
        private readonly AppDbContext _context;
        private readonly ILogger<LogParser> _logger;
        private readonly string _logFilePath;

        public LogParser(AppDbContext context, ILogger<LogParser> logger, IConfiguration configuration)
        {
            _context = context;
            _logger = logger;
            _logFilePath = configuration["LogSettings:LogFilePath"] ?? "/app/logs/access.log";
        }

        public async Task ParseLogsAsync()
        {
            if (!File.Exists(_logFilePath))
            {
                _logger.LogError("❌ Файл логов не найден: {FilePath}", _logFilePath);
                return;
            }

            var logPattern = @"^(?<timestamp>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3} \+\d{2}:\d{2}) \[(?<level>[A-Z]+)\] (?<message>.+)$";

            var logs = new List<LogEntry>();
            int processedLines = 0, skippedLines = 0;

            foreach (var line in await File.ReadAllLinesAsync(_logFilePath))
            {
                var match = Regex.Match(line, logPattern);
                if (match.Success)
                {
                    try
                    {
                        var timestamp = DateTime.SpecifyKind(
                            DateTime.Parse(match.Groups["timestamp"].Value),
                            DateTimeKind.Utc
                        );

                        logs.Add(new LogEntry
                        {
                            Timestamp = timestamp,
                            IPAddress = "-",
                            User = "-",
                            Request = match.Groups["message"].Value,
                            StatusCode = 0,
                            ResponseSize = 0
                        });
                        processedLines++;
                    }
                    catch (Exception ex)
                    {
                        skippedLines++;
                        _logger.LogWarning("❌ Ошибка при обработке строки: {Line}. Исключение: {Exception}", line, ex.Message);
                    }
                }
                else
                {
                    skippedLines++;
                    _logger.LogWarning("⚠️ Строка не соответствует формату: {Line}", line);
                }
            }

            if (logs.Any())
            {
                await _context.LogEntries.AddRangeAsync(logs);
                await _context.SaveChangesAsync();
            }

            _logger.LogInformation("✅ Логи успешно распознаны и сохранены. Обработано: {Processed}, Пропущено: {Skipped}", processedLines, skippedLines);
        }
    }
}
