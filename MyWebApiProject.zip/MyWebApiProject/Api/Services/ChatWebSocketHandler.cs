using System.Net.WebSockets;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.DependencyInjection;
using MyWebApiProject.Models;
using MyWebApiProject.Services;
using Microsoft.EntityFrameworkCore;

namespace MyWebApiProject.Services
{
    public class ChatWebSocketHandler
    {
        private readonly ILogger<ChatWebSocketHandler> _logger;
        private readonly IServiceScopeFactory _scopeFactory;
        private static readonly Dictionary<string, WebSocket> _connections = new();

        public ChatWebSocketHandler(ILogger<ChatWebSocketHandler> logger, IServiceScopeFactory scopeFactory)
        {
            _logger = logger;
            _scopeFactory = scopeFactory;
        }

        public async Task HandleWebSocketAsync(WebSocket webSocket, string userId)
        {
            var buffer = new byte[1024 * 4];
            _connections[userId] = webSocket;

            _logger.LogInformation("✅ WebSocket-соединение установлено для пользователя {UserId}", userId);

            try
            {
                await SendChatHistoryAsync(webSocket, userId);

                while (webSocket.State == WebSocketState.Open)
                {
                    var result = await webSocket.ReceiveAsync(new ArraySegment<byte>(buffer), CancellationToken.None);

                    if (result.MessageType == WebSocketMessageType.Close)
                    {
                        await webSocket.CloseAsync(WebSocketCloseStatus.NormalClosure, "Соединение закрыто", CancellationToken.None);
                        _logger.LogInformation("❌ WebSocket-соединение закрыто для пользователя {UserId}", userId);
                        _connections.Remove(userId);
                        break;
                    }

                    var messageJson = Encoding.UTF8.GetString(buffer, 0, result.Count);
                    var chatMessage = JsonSerializer.Deserialize<ChatMessage>(messageJson);

                    if (chatMessage != null)
                    {
                        using (var scope = _scopeFactory.CreateScope())
                        {
                            var context = scope.ServiceProvider.GetRequiredService<AppDbContext>();

                            var recipient = await context.Users.FindAsync(chatMessage.ToUserId);
                            if (recipient == null)
                            {
                                _logger.LogWarning("⚠️ Получатель с ID {ToUserId} не существует.", chatMessage.ToUserId);
                                continue;
                            }

                            var message = new Message
                            {
                                FromUserId = userId,
                                ToUserId = chatMessage.ToUserId,
                                MessageText = chatMessage.MessageText,
                                CreatedAt = DateTime.UtcNow
                            };

                            context.Messages.Add(message);
                            await context.SaveChangesAsync();

                            _logger.LogInformation("📤 Сообщение от {FromUserId} к {ToUserId}: {MessageText}", userId, chatMessage.ToUserId, chatMessage.MessageText);

                            if (_connections.TryGetValue(chatMessage.ToUserId, out var recipientWebSocket) &&
                                recipientWebSocket.State == WebSocketState.Open)
                            {
                                var responseMessage = $"Сообщение от {userId}: {chatMessage.MessageText}";
                                var responseBytes = Encoding.UTF8.GetBytes(responseMessage);

                                await recipientWebSocket.SendAsync(
                                    new ArraySegment<byte>(responseBytes),
                                    WebSocketMessageType.Text,
                                    true,
                                    CancellationToken.None);

                                _logger.LogInformation("📤 Сообщение отправлено пользователю {ToUserId}", chatMessage.ToUserId);
                            }
                            else
                            {
                                _logger.LogWarning("⚠️ Пользователь {ToUserId} не в сети", chatMessage.ToUserId);
                            }

                            if (_connections.TryGetValue(userId, out var senderWebSocket) &&
                                senderWebSocket.State == WebSocketState.Open)
                            {
                                var senderResponseMessage = $"Вы: {chatMessage.MessageText}";
                                var senderResponseBytes = Encoding.UTF8.GetBytes(senderResponseMessage);

                                await senderWebSocket.SendAsync(
                                    new ArraySegment<byte>(senderResponseBytes),
                                    WebSocketMessageType.Text,
                                    true,
                                    CancellationToken.None);

                                _logger.LogInformation("📤 Сообщение отправлено отправителю {UserId}", userId);
                            }
                        }
                    }
                    else
                    {
                        _logger.LogWarning("⚠️ Некорректный формат сообщения: {MessageJson}", messageJson);
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("❌ Ошибка WebSocket-соединения: {Message}", ex.Message);
            }
            finally
            {
                _connections.Remove(userId);
            }
        }

        private async Task SendChatHistoryAsync(WebSocket webSocket, string userId)
        {
            using (var scope = _scopeFactory.CreateScope())
            {
                var context = scope.ServiceProvider.GetRequiredService<AppDbContext>();

                var history = await context.Messages
                    .Where(m => m.FromUserId == userId || m.ToUserId == userId)
                    .OrderBy(m => m.CreatedAt)
                    .Take(50)
                    .ToListAsync();

                foreach (var message in history)
                {
                    var formattedMessage = $"История: {message.CreatedAt:yyyy-MM-dd HH:mm:ss} | {message.FromUserId} -> {message.ToUserId}: {message.MessageText}";
                    var messageBytes = Encoding.UTF8.GetBytes(formattedMessage);

                    await webSocket.SendAsync(
                        new ArraySegment<byte>(messageBytes),
                        WebSocketMessageType.Text,
                        true,
                        CancellationToken.None);

                    _logger.LogInformation("📜 Отправлено сообщение истории: {Message}", formattedMessage);
                }
            }

            _logger.LogInformation("📚 История сообщений отправлена пользователю {UserId}", userId);
        }

        private class ChatMessage
        {
            public string ToUserId { get; set; } = default!;
            public string MessageText { get; set; } = default!;
        }
    }
}
