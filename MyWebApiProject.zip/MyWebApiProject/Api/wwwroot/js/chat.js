const userId = prompt("Введите ваш UserID для подключения к чату:");

if (!userId) {
  alert("UserID обязателен для подключения.");
} else {
  const socket = new WebSocket(`ws://${window.location.host}/ws/chat?userId=${userId}`);

  socket.onopen = () => {
    console.log("✅ Подключено к WebSocket-серверу");
  };

  socket.onmessage = (event) => {
    const message = event.data;

    if (message.startsWith("История:")) {
      displayMessage(message, "history");
    } else {
      displayMessage(message, "new");
    }
  };

  socket.onclose = (event) => {
    console.log(`❌ Соединение закрыто: ${event.code}, причина: ${event.reason}`);
  };

  socket.onerror = (error) => {
    console.error("❌ Ошибка WebSocket:", error);
  };

  document.getElementById("sendButton").addEventListener("click", () => {
    const toUserId = document.getElementById("toUserId").value;
    const messageText = document.getElementById("messageInput").value;

    if (!toUserId || !messageText) {
      alert("Заполните ID получателя и сообщение!");
      return;
    }

    const message = {
      ToUserId: toUserId,
      MessageText: messageText
    };

    socket.send(JSON.stringify(message));
    document.getElementById("messageInput").value = "";
  });

  function displayMessage(message, type) {
    const chatWindow = document.getElementById("chatWindow");
    const messageElement = document.createElement("div");
    messageElement.textContent = message;

    if (type === "history") {
      messageElement.style.color = "gray";
    } else {
      messageElement.style.color = "black";
    }

    chatWindow.appendChild(messageElement);
    chatWindow.scrollTop = chatWindow.scrollHeight;
  }
}
