using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MyWebApiProject.Models;
using MyWebApiProject.Services;

namespace MyWebApiProject.Controllers
{
    [ApiController]
    [Route("api/logs")]
    public class LogController : ControllerBase
    {
        private readonly AppDbContext _context;

        public LogController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllLogs()
        {
            var logs = await _context.LogEntries.ToListAsync();
            return Ok(logs);
        }

        [HttpGet("by-ip")]
        public async Task<IActionResult> GetLogsByIP([FromQuery] string ip)
        {
            if (string.IsNullOrEmpty(ip))
                return BadRequest("IP-адрес обязателен.");

            var logs = await _context.LogEntries
                .Where(log => log.IPAddress == ip)
                .ToListAsync();

            if (!logs.Any())
                return NotFound($"Логи для IP-адреса {ip} не найдены.");

            return Ok(logs);
        }

        [HttpGet("by-date")]
        public async Task<IActionResult> GetLogsByDate([FromQuery] DateTime date)
        {
            if (date == default)
                return BadRequest("Дата обязательна.");

            var logs = await _context.LogEntries
                .Where(log => log.Timestamp.Date == date.Date)
                .ToListAsync();

            if (!logs.Any())
                return NotFound($"Логи за дату {date.Date.ToShortDateString()} не найдены.");

            return Ok(logs);
        }

        [HttpGet("by-date-range")]
        public async Task<IActionResult> GetLogsByDateRange([FromQuery] DateTime start, [FromQuery] DateTime end)
        {
            if (start == default || end == default)
                return BadRequest("Обе даты (start и end) обязательны.");

            if (start > end)
                return BadRequest("Начальная дата не может быть больше конечной.");

            var logs = await _context.LogEntries
                .Where(log => log.Timestamp >= start && log.Timestamp <= end)
                .ToListAsync();

            if (!logs.Any())
                return NotFound($"Логи в диапазоне с {start} по {end} не найдены.");

            return Ok(logs);
        }

        [HttpGet("group-by-ip")]
        public async Task<IActionResult> GroupLogsByIP()
        {
            var groupedLogs = await _context.LogEntries
                .GroupBy(log => log.IPAddress)
                .Select(group => new
                {
                    IPAddress = group.Key,
                    Count = group.Count()
                })
                .OrderByDescending(group => group.Count)
                .ToListAsync();

            if (!groupedLogs.Any())
                return NotFound("Логи для группировки по IP отсутствуют.");

            return Ok(groupedLogs);
        }

        [HttpGet("group-by-date")]
        public async Task<IActionResult> GroupLogsByDate()
        {
            var groupedLogs = await _context.LogEntries
                .GroupBy(log => log.Timestamp.Date)
                .Select(group => new
                {
                    Date = group.Key,
                    Count = group.Count()
                })
                .OrderByDescending(group => group.Date)
                .ToListAsync();

            if (!groupedLogs.Any())
                return NotFound("Логи для группировки по дате отсутствуют.");

            return Ok(groupedLogs);
        }
    }
}
