using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using MyWebApiProject.Models;
using MyWebApiProject.Services;

namespace MyWebApiProject.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class UserController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly UserManager<AppUser> _userManager;

        public UserController(AppDbContext context, UserManager<AppUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        [Authorize(Roles = "Admin")]
        [HttpGet]
        public IActionResult GetAllUsers()
        {
            var users = _context.Users.ToList();
            return Ok(users);
        }

        [HttpGet("{id}")]
        public IActionResult GetUserById(string id)
        {
            var user = _context.Users.Find(id);
            if (user == null)
                return NotFound($"User with ID={id} not found.");

            return Ok(user);
        }

        [HttpGet("by-username/{username}")]
        public async Task<IActionResult> GetUserByUsername(string username)
        {
            var user = await _userManager.FindByNameAsync(username);
            if (user == null)
                return NotFound($"User with username='{username}' not found.");

            return Ok(new { user.Id });
        }

        [HttpPost]
        public IActionResult CreateUser([FromBody] AppUser user)
        {
            _context.Users.Add(user);
            _context.SaveChanges();
            return CreatedAtAction(nameof(GetUserById), new { id = user.Id }, user);
        }

        [Authorize]
        [HttpPut("{id}")]
        public IActionResult UpdateUser(string id, [FromBody] AppUser updatedUser)
        {
            var user = _context.Users.Find(id);
            if (user == null)
                return NotFound($"User with ID={id} not found.");

            user.UserName = updatedUser.UserName;
            user.Email = updatedUser.Email;

            _context.SaveChanges();
            return NoContent();
        }

        [Authorize]
        [HttpDelete("{id}")]
        public IActionResult DeleteUser(string id)
        {
            var user = _context.Users.Find(id);
            if (user == null)
                return NotFound($"User with ID={id} not found.");

            _context.Users.Remove(user);
            _context.SaveChanges();
            return NoContent();
        }
    }
}
