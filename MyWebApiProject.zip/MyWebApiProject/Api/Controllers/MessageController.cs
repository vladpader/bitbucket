using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MyWebApiProject.Models;
using MyWebApiProject.Services;

namespace MyWebApiProject.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class MessageController : ControllerBase
    {
        private readonly AppDbContext _context;

        public MessageController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult GetAllMessages()
        {
            var messages = _context.Messages.ToList();
            return Ok(messages);
        }

        [HttpGet("{id}")]
        public IActionResult GetMessageById(int id)
        {
            var message = _context.Messages.Find(id);
            if (message == null)
                return NotFound($"Message with ID={id} not found.");

            return Ok(message);
        }

        [HttpPost]
        public IActionResult SendMessage([FromBody] Message msg)
        {
            msg.CreatedAt = DateTime.UtcNow;
            _context.Messages.Add(msg);
            _context.SaveChanges();

            return CreatedAtAction(nameof(GetMessageById), new { id = msg.Id }, msg);
        }

        [HttpPut("{id}")]
        public IActionResult UpdateMessage(int id, [FromBody] Message updated)
        {
            var msg = _context.Messages.Find(id);
            if (msg == null)
                return NotFound($"Message with ID={id} not found.");

            msg.FromUserId = updated.FromUserId;
            msg.ToUserId = updated.ToUserId;
            msg.MessageText = updated.MessageText;
            msg.CreatedAt = updated.CreatedAt;

            _context.SaveChanges();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteMessage(int id)
        {
            var msg = _context.Messages.Find(id);
            if (msg == null)
                return NotFound($"Message with ID={id} not found.");

            _context.Messages.Remove(msg);
            _context.SaveChanges();
            return NoContent();
        }
    }
}
