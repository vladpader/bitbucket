using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using MyWebApiProject.Models;

namespace MyWebApiProject.Controllers
{
    [ApiController]
    [Route("api/admin")]
    public class AdminController : ControllerBase
    {
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly UserManager<AppUser> _userManager;

        public AdminController(RoleManager<IdentityRole> roleManager, UserManager<AppUser> userManager)
        {
            _roleManager = roleManager;
            _userManager = userManager;
        }

        [HttpPost("create-admin")]
        [AllowAnonymous]
        public async Task<IActionResult> CreateAdmin([FromHeader] string apiKey)
        {
            var validApiKey = "supersecretkey";
            if (apiKey != validApiKey)
            {
                return Unauthorized("❌ Invalid API Key");
            }

            try
            {
                string[] roles = { "Admin", "User" };
                foreach (var role in roles)
                {
                    if (!await _roleManager.RoleExistsAsync(role))
                    {
                        await _roleManager.CreateAsync(new IdentityRole(role));
                        Console.WriteLine($"✅ Роль '{role}' успешно создана.");
                    }
                }

                var adminEmail = "admin@example.com";
                var adminUser = await _userManager.FindByEmailAsync(adminEmail);

                if (adminUser == null)
                {
                    var user = new AppUser
                    {
                        UserName = "admin",
                        Email = adminEmail,
                        EmailConfirmed = true
                    };

                    var result = await _userManager.CreateAsync(user, "Admin123!");
                    if (result.Succeeded)
                    {
                        await _userManager.AddToRoleAsync(user, "Admin");
                        Console.WriteLine("✅ Администратор успешно создан.");
                        return Ok("✅ Администратор успешно создан.");
                    }
                    else
                    {
                        Console.WriteLine($"❌ Ошибка при создании администратора: {string.Join(", ", result.Errors.Select(e => e.Description))}");
                        return BadRequest("❌ Ошибка при создании администратора.");
                    }
                }
                else
                {
                    Console.WriteLine("⚠️ Администратор уже существует.");
                    return Ok("⚠️ Администратор уже существует.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Ошибка при инициализации данных: {ex.Message}");
                return StatusCode(500, $"❌ Критическая ошибка: {ex.Message}");
            }
        }
    }
}
