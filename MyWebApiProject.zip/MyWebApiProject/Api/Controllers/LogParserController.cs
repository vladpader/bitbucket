using Microsoft.AspNetCore.Mvc;
using MyWebApiProject.Services;

namespace MyWebApiProject.Controllers
{
    [ApiController]
    [Route("api/logs/parser")]
    public class LogParserController : ControllerBase
    {
        private readonly LogParser _parser;

        public LogParserController(LogParser parser)
        {
            _parser = parser;
        }

        [HttpPost("parse")]
        public async Task<IActionResult> ParseLogs()
        {
            await _parser.ParseLogsAsync();
            return Ok("Парсинг логов завершён.");
        }
    }
}
