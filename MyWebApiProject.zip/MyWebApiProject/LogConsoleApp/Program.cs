﻿using System.Net.Http.Json;
using Microsoft.Extensions.Configuration;

class Program
{
    private static readonly HttpClient _httpClient = new HttpClient();
    private static IConfiguration _configuration = null!;

    static async Task Main(string[] args)
    {
        _configuration = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
            .Build();

        var apiBaseUrl = _configuration["ApiSettings:BaseUrl"];

        if (string.IsNullOrEmpty(apiBaseUrl))
        {
            Console.WriteLine("❌ Ошибка: BaseUrl не указан в конфигурации.");
            return;
        }

        try
        {
            _httpClient.BaseAddress = new Uri(apiBaseUrl);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"❌ Ошибка: Некорректный URL '{apiBaseUrl}'. Исключение: {ex.Message}");
            return;
        }

        Console.WriteLine("🚀 Консольное приложение для работы с логами");
        Console.WriteLine("1. Просмотреть все логи");
        Console.WriteLine("2. Фильтрация по IP-адресу");
        Console.WriteLine("3. Фильтрация по дате");
        Console.WriteLine("4. Фильтрация по диапазону дат");
        Console.WriteLine("5. Группировка по IP");
        Console.WriteLine("6. Группировка по дате");
        Console.WriteLine("7. Выход");

        while (true)
        {
            Console.Write("Введите номер действия: ");
            var choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    await GetAllLogs();
                    break;
                case "2":
                    await GetLogsByIP();
                    break;
                case "3":
                    await GetLogsByDate();
                    break;
                case "4":
                    await GetLogsByDateRange();
                    break;
                case "5":
                    await GroupLogsByIP();
                    break;
                case "6":
                    await GroupLogsByDate();
                    break;
                case "7":
                    return;
                default:
                    Console.WriteLine("❌ Некорректный ввод, попробуйте снова.");
                    break;
            }
        }
    }

    private static async Task GetAllLogs()
    {
        var logs = await _httpClient.GetFromJsonAsync<List<LogEntry>>("api/logs");
        PrintLogs(logs);
    }

    private static async Task GetLogsByIP()
    {
        Console.Write("Введите IP-адрес: ");
        var ip = Console.ReadLine();
        var logs = await _httpClient.GetFromJsonAsync<List<LogEntry>>($"api/logs/by-ip?ip={ip}");
        PrintLogs(logs);
    }

    private static async Task GetLogsByDate()
    {
        Console.Write("Введите дату (yyyy-MM-dd): ");
        var date = Console.ReadLine();
        var logs = await _httpClient.GetFromJsonAsync<List<LogEntry>>($"api/logs/by-date?date={date}");
        PrintLogs(logs);
    }

    private static async Task GetLogsByDateRange()
    {
        Console.Write("Введите начальную дату (yyyy-MM-dd): ");
        var start = Console.ReadLine();
        Console.Write("Введите конечную дату (yyyy-MM-dd): ");
        var end = Console.ReadLine();
        var logs = await _httpClient.GetFromJsonAsync<List<LogEntry>>($"api/logs/by-date-range?start={start}&end={end}");
        PrintLogs(logs);
    }

    private static async Task GroupLogsByIP()
    {
        var groupedLogs = await _httpClient.GetFromJsonAsync<List<GroupedLog>>("api/logs/group-by-ip");
        foreach (var log in groupedLogs ?? new List<GroupedLog>())
        {
            Console.WriteLine($"IP: {log.Key}, Количество: {log.Count}");
        }
    }

    private static async Task GroupLogsByDate()
    {
        var groupedLogs = await _httpClient.GetFromJsonAsync<List<GroupedLog>>("api/logs/group-by-date");
        foreach (var log in groupedLogs ?? new List<GroupedLog>())
        {
            Console.WriteLine($"Дата: {log.Key}, Количество: {log.Count}");
        }
    }

    private static void PrintLogs(List<LogEntry>? logs)
    {
        if (logs == null || logs.Count == 0)
        {
            Console.WriteLine("⚠️ Логи не найдены.");
            return;
        }

        foreach (var log in logs)
        {
            Console.WriteLine($"{log.Timestamp} | {log.IPAddress} | {log.User} | {log.Request} | {log.StatusCode}");
        }
    }

    public class LogEntry
    {
        public int Id { get; set; }
        public string IPAddress { get; set; } = string.Empty;
        public string User { get; set; } = string.Empty;
        public DateTime Timestamp { get; set; }
        public string Request { get; set; } = string.Empty;
        public int StatusCode { get; set; }
        public int ResponseSize { get; set; }
    }

    public class GroupedLog
    {
        public string Key { get; set; } = string.Empty;
        public int Count { get; set; }
    }
}
